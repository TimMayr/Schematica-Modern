package com.github.lunatrius.core.exceptions;


import net.minecraft.class_2561;

public class LocalizedException extends Exception {
	public LocalizedException(String format) {
		super(String.valueOf(class_2561.method_43471(format)));
	}

	public LocalizedException(String format, Object... arguments) {
		super(String.valueOf(class_2561.method_43469(format, arguments)));
	}
}
package com.github.lunatrius.core.entity;

import com.github.lunatrius.core.util.vector.Vector3f;
import com.github.lunatrius.core.util.vector.Vector3i;
import net.minecraft.class_1297;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;

public class EntityHelper {
	public static final int WILDCARD = -1;

	public static int getItemCountInInventory(class_1661 inventory, class_1792 item) {
		return getItemCountInInventory(inventory, item, WILDCARD);
	}

	public static int getItemCountInInventory(class_1661 inventory, class_1792 item, int itemDamage) {
		int inventorySize = inventory.method_5439();
		int count = 0;

		for (int slot = 0; slot < inventorySize; slot++) {
			class_1799 itemStack = inventory.method_5438(slot);

			if (itemStack.method_7909() == item && (itemDamage == WILDCARD || itemDamage == itemStack.method_7919())) {
				count += itemStack.method_7947();
			}
		}

		return count;
	}

	public static Vector3f getVector3fFromEntity(class_1297 entity) {
		return new Vector3f((float) entity.method_23317(), (float) entity.method_23318(), (float) entity.method_23321());
	}

	public static Vector3f getVector3fFromEntity(class_1297 entity, Vector3f vec) {
		return vec.set((float) entity.method_23317(), (float) entity.method_23318(), (float) entity.method_23321());
	}

	public static Vector3i getVector3iFromEntity(class_1297 entity) {
		return new Vector3i((int) Math.floor(entity.method_23317()), (int) Math.floor(entity.method_23318()),
		                    (int) Math.floor(entity.method_23321()));
	}

	public static Vector3i getVector3iFromEntity(class_1297 entity, Vector3i vec) {
		return vec.set((int) Math.floor(entity.method_23317()), (int) Math.floor(entity.method_23318()),
		               (int) Math.floor(entity.method_23321()));
	}
}
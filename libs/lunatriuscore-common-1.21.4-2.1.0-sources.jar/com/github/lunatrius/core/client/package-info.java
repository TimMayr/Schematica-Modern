//@formatter:off
@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
@Environment(EnvType.CLIENT)
//@formatter:on
package com.github.lunatrius.core.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
package com.github.lunatrius.core.client.gui;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_5244;
import net.minecraft.class_7077;

public class NumericFieldWidget extends class_4185 {
	private static final int DEFAULT_VALUE = 0;
	private static final int BUTTON_WIDTH = 12;

	private final class_342 guiEditBox;
	private final class_7077 guiButtonDec;
	private final class_7077 guiButtonInc;

	private String previous = String.valueOf(DEFAULT_VALUE);
	private int minimum = Integer.MIN_VALUE;
	private int maximum = Integer.MAX_VALUE;
	private boolean wasFocused = false;

	public NumericFieldWidget(int x, int y, class_4185.class_4241 onPress) {
		this(x, y, 100, 20, onPress);
	}

	public NumericFieldWidget(int x, int y, int width, int height, class_4185.class_4241 onPress) {
		super(0, 0, width, height, class_5244.field_39003, onPress, field_40754);
		this.guiEditBox =
				new class_342(class_310.method_1551().field_1772, x + 1, y + 1, width - BUTTON_WIDTH * 2 - 2, height - 2,
				            class_5244.field_39003);

		this.guiButtonDec =
				new class_7077(x + width - BUTTON_WIDTH * 2, y, BUTTON_WIDTH, height, class_2561.method_43470("-"),
				                    (event) -> {}, class_310.method_1551().field_1772);

		this.guiButtonInc =
				new class_7077(x + width - BUTTON_WIDTH, y, BUTTON_WIDTH, height, class_2561.method_43470("+"),
				                    (event) -> {}, class_310.method_1551().field_1772);

		setValue(DEFAULT_VALUE);
	}

	public NumericFieldWidget(int x, int y, int width, class_4185.class_4241 onPress) {
		this(x, y, width, 20, onPress);
	}

	@Override
	protected void method_48579(class_332 guiGraphics, int x, int y, float partialTicks) {
		if (this.field_22764) {
			this.guiEditBox.method_48579(guiGraphics, x, y, partialTicks);
			this.guiButtonInc.method_48579(guiGraphics, x, y, partialTicks);
			this.guiButtonDec.method_48579(guiGraphics, x, y, partialTicks);
		}
	}

	@Override
	public void method_25348(double x, double y) {
		this.guiButtonDec.method_25348(x, y);
		this.guiButtonInc.method_25348(x, y);
		this.guiEditBox.method_25348(x, y);
		super.method_25348(x, y);
	}

	@Override
	public boolean method_25404(int character, int code, int modifiers) {
		this.guiEditBox.method_25404(character, code, modifiers);
		this.guiButtonDec.method_25404(character, code, modifiers);
		this.guiButtonInc.method_25404(character, code, modifiers);
		return super.method_25404(character, code, modifiers);
	}

	@Override
	public boolean method_25402(double mouseX, double mouseY, int button) {
		if (this.wasFocused && !this.guiEditBox.method_25370()) {
			this.wasFocused = false;
			return true;
		}

		this.wasFocused = this.guiEditBox.method_25370();

		if (this.guiButtonDec.method_25402(mouseX, mouseY, button)) {
			setValue(getValue() - 1);
			this.method_25306();
			return true;
		}

		if (this.guiButtonInc.method_25402(mouseX, mouseY, button)) {
			setValue(getValue() + 1);
			this.method_25306();
			return true;
		}

		if (this.guiEditBox.method_25402(mouseX, mouseY, button)) {
			setValue(Integer.parseInt(guiEditBox.method_1882()));
			this.method_25306();
			return true;
		}

		return false;
	}

	public boolean method_25370() {
		return this.guiEditBox.method_25370();
	}

	public int getValue() {
		String text = this.guiEditBox.method_1882();

		if (text.isEmpty() || text.equals("-")) {
			return DEFAULT_VALUE;
		}

		return Integer.parseInt(text);
	}

	public void setValue(int value) {
		if (value > this.maximum) {
			value = this.maximum;
		} else if (value < this.minimum) {
			value = this.minimum;
		}
		this.guiEditBox.method_1852(String.valueOf(value));
	}

	@Override
	public boolean method_25400(char character, int code) {
		if (!this.guiEditBox.method_25370()) {
			return false;
		}

		int cursorPositionOld = this.guiEditBox.method_1881();

		this.guiEditBox.method_25400(character, code);

		String text = this.guiEditBox.method_1882();
		int cursorPositionNew = this.guiEditBox.method_1881();

		if (text.isEmpty() || text.equals("-")) {
			return true;
		}

		try {
			long value = Long.parseLong(text);
			boolean outOfRange = false;

			if (value > this.maximum) {
				value = this.maximum;
				outOfRange = true;
			} else if (value < this.minimum) {
				value = this.minimum;
				outOfRange = true;
			}

			text = String.valueOf(value);

			if (!text.equals(this.previous) || outOfRange) {
				this.guiEditBox.method_1852(String.valueOf(value));
				this.guiEditBox.method_1875(cursorPositionNew);
			}

			this.previous = text;
			this.method_25306();
			return true;
		} catch (NumberFormatException nfe) {
			this.guiEditBox.method_1852(this.previous);
			this.guiEditBox.method_1875(cursorPositionOld);
		}

		return false;
	}

	public void method_48229(int x, int y) {
		this.guiEditBox.method_48229(x + 1, y + 1);
		this.guiButtonInc.method_48229(x + field_22758 - BUTTON_WIDTH * 2, y);
		this.guiButtonDec.method_48229(x + field_22758 - BUTTON_WIDTH, y);
	}

	public void setActive(boolean active) {
		this.field_22763 = active;
		this.guiEditBox.field_22763 = active;
		this.guiButtonInc.field_22763 = active;
		this.guiButtonDec.field_22763 = active;
	}

	public int getMinimum() {
		return this.minimum;
	}

	public void setMinimum(int minimum) {
		this.minimum = minimum;
	}

	public int getMaximum() {
		return this.maximum;
	}

	public void setMaximum(int maximum) {
		this.maximum = maximum;
	}
}
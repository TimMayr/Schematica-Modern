package com.github.lunatrius.core.client.gui;


import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_364;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import org.jetbrains.annotations.NotNull;

public class ScreenBase extends class_437 {
	protected final class_437 parentScreen;

	public ScreenBase() {
		this(null);
	}

	public ScreenBase(class_437 parentScreen) {
		super(class_5244.field_39003);
		this.parentScreen = parentScreen;
	}

	@Override
	public boolean method_25402(double mouseX, double mouseY, int mouseEvent) {
		for (class_364 child : this.method_25396()) {
			if (child instanceof NumericFieldWidget numericField) {
				if (numericField.method_25402(mouseX, mouseY, mouseEvent)) {
					return true;
				}
			} else if (child instanceof class_342 textArea) {
				if (textArea.method_25402(mouseX, mouseY, mouseEvent)) {
					return true;
				}
			} else {
				if (child.method_25402(mouseX, mouseY, mouseEvent)) {
					return true;
				}
			}
		}

		return super.method_25402(mouseX, mouseY, mouseEvent);
	}

	public boolean method_25400(char character, int code) {
		for (class_364 child : this.method_25396()) {
			if (child instanceof NumericFieldWidget numericField) {
				if (numericField.method_25400(character, code)) {
					return true;
				}
			} else if (child instanceof class_342 textArea) {
				if (textArea.method_25400(character, code)) {
					return true;
				}
			}
		}

		return super.method_25400(character, code);
	}

	@Override
	public void method_25394(@NotNull class_332 guiGraphics, int x, int y, float partialTicks) {
		super.method_25394(guiGraphics, x, y, partialTicks);

		for (class_364 child : this.method_25396()) {
			if (child instanceof class_342 textArea) {
				textArea.method_25394(guiGraphics, x, y, partialTicks);
			}
		}
	}

	@Override
	public boolean method_25404(int character, int code, int modifiers) {
		if (code == class_3675.field_31958) {
			if (this.field_22787 == null) {
				return false;
			}

			this.field_22787.method_1507(this.parentScreen);
			return true;
		}

		for (class_364 child : this.method_25396()) {
			if (child instanceof NumericFieldWidget numericField) {
				if (numericField.method_25404(character, code, modifiers)) {
					numericField.method_25306();
					return true;
				}
			} else if (child instanceof class_342 textArea) {
				textArea.method_25404(character, code, modifiers);
			}
		}

		return super.method_25404(character, code, modifiers);
	}

	@Override
	public void method_25426() {
		this.method_25396().clear();
	}
}
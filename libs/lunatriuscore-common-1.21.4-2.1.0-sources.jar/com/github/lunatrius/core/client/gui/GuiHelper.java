package com.github.lunatrius.core.client.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.class_1060;
import net.minecraft.class_1799;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_811;
import net.minecraft.class_918;
import net.minecraft.class_9799;
import org.jetbrains.annotations.NotNull;

public class GuiHelper {
	private static final class_2960 STAT_ICONS =
			class_2960.method_60655("minecraft", "textures/gui/container/stats_icons.png");

	public static void drawItemStackWithSlot(class_1060 textureManager, class_1799 itemStack, int x, int y) {
		drawItemStackSlot(x, y);

		if (itemStack != null) {
			drawItemStack(itemStack, x + 2, y + 2);
		}
	}

	public static void drawItemStackSlot(int x, int y) {
		RenderSystem.setShaderTexture(0, STAT_ICONS);
		RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);

		class_289 tesselator = class_289.method_1348();
		class_287 buffer = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1585);
		float uScale = (float) (1.0 / 128.0);
		float vScale = (float) (1.0 / 128.0);

		drawTexturedRectangle(buffer, x + 1, y + 1, x + 1 + 18, y + 1 + 18, 0, uScale * 0, vScale * 0, uScale * 18,
		                      vScale * 18);
	}

	public static void drawTexturedRectangle(class_287 buffer, float x0, float y0, float x1, float y1, float z,
	                                         float u0, float v0, float u1, float v1) {
		buffer.method_22912(x0, y0, z).method_22913(u0, v0);
		buffer.method_22912(x0, y1, z).method_22913(u0, v1);
		buffer.method_22912(x1, y1, z).method_22913(u1, v1);
		buffer.method_22912(x1, y0, z).method_22913(u1, v0);
	}

	public static void drawItemStack(class_1799 itemStack, int x, int y) {
		class_310 mc = class_310.method_1551();
		class_918 itemRenderer = mc.method_1480();
		class_4587 poseStack = new class_4587();
		class_4597 bufferSource = class_4597.method_22991(new class_9799(1536));

		// Prepare rendering
		RenderSystem.enableDepthTest();
		poseStack.method_46416(x, y, 100); // Render in front of GUI elements if needed

		// Render the item
		itemRenderer.method_23178(itemStack, class_811.field_4317, 15, 0, poseStack, bufferSource, mc.field_1687,
		                          (int) (Math.random() * 1000));

		// Clean up
		RenderSystem.disableDepthTest();
	}

	public static void drawTexturedRectangle(class_287 buffer, float x0, float y0, float x1, float y1, float z,
	                                         double textureWidth, double textureHeight, int argb) {
		float u0 = (float) (x0 / textureWidth);
		float v0 = (float) (y0 / textureHeight);
		float u1 = (float) (x1 / textureWidth);
		float v1 = (float) (y1 / textureHeight);

		drawTexturedRectangle(buffer, x0, y0, x1, y1, z, u0, v0, u1, v1, argb);
	}

	public static void drawTexturedRectangle(class_287 buffer, float x0, float y0, float x1, float y1, float z,
	                                         float u0, float v0, float u1, float v1, int argb) {
		int a = (argb >> 24) & 0xFF;
		int r = (argb >> 16) & 0xFF;
		int g = (argb >> 8) & 0xFF;
		int b = argb & 0xFF;

		drawTexturedRectangle(buffer, x0, y0, x1, y1, z, u0, v0, u1, v1, r, g, b, a);
	}

	public static void drawTexturedRectangle(class_287 buffer, float x0, float y0, float x1, float y1, float z,
	                                         float u0, float v0, float u1, float v1, int r, int g, int b, int a) {
		buffer.method_22912(x0, y0, z).method_22913(u0, v0).method_1336(r, g, b, a);
		buffer.method_22912(x0, y1, z).method_22913(u0, v1).method_1336(r, g, b, a);
		buffer.method_22912(x1, y1, z).method_22913(u1, v1).method_1336(r, g, b, a);
		buffer.method_22912(x1, y0, z).method_22913(u1, v0).method_1336(r, g, b, a);
	}

	public static void drawColoredRectangle(class_287 buffer, float x0, float y0, float x1, float y1, float z,
	                                        int argb) {
		int a = (argb >> 24) & 0xFF;
		int r = (argb >> 16) & 0xFF;
		int g = (argb >> 8) & 0xFF;
		int b = argb & 0xFF;

		drawColoredRectangle(buffer, x0, y0, x1, y1, z, r, g, b, a);
	}

	public static void drawColoredRectangle(class_287 buffer, float x0, float y0, float x1, float y1, float z,
	                                        int r, int g, int b, int a) {
		drawVerticalGradientRectangle(buffer, x0, y0, x1, y1, z, r, g, b, a, r, g, b, a);
	}

	public static void drawVerticalGradientRectangle(class_287 buffer, float x0, float y0, float x1, float y1,
	                                                 float z, int sr, int sg, int sb, int sa, int er, int eg, int eb,
	                                                 int ea) {
		buffer.method_22912(x0, y0, z).method_1336(sr, sg, sb, sa);
		buffer.method_22912(x0, y1, z).method_1336(er, eg, eb, ea);
		buffer.method_22912(x1, y1, z).method_1336(er, eg, eb, ea);
		buffer.method_22912(x1, y0, z).method_1336(sr, sg, sb, sa);
	}

	public static void drawVerticalGradientRectangle(class_287 buffer, float x0, float y0, float x1, float y1,
	                                                 float z, int startColor, int endColor) {
		ColorComponents components = getColorComponents(startColor, endColor);

		drawVerticalGradientRectangle(buffer, x0, y0, x1, y1, z, components.sr(), components.sg(), components.sb(),
		                              components.sa(), components.er(), components.eg(), components.eb(),
		                              components.ea());
	}

	private static @NotNull ColorComponents getColorComponents(int startColor, int endColor) {
		int sa = (startColor >> 24) & 255;
		int sr = (startColor >> 16) & 255;
		int sg = (startColor >> 8) & 255;
		int sb = startColor & 255;
		int ea = (endColor >> 24) & 255;
		int er = (endColor >> 16) & 255;
		int eg = (endColor >> 8) & 255;
		int eb = endColor & 255;
		return new ColorComponents(sa, sr, sg, sb, ea, er, eg, eb);
	}

	public static void drawHorizontalGradientRectangle(class_287 buffer, float x0, float y0, float x1, float y1,
	                                                   float z, int startColor, int endColor) {
		ColorComponents components = getColorComponents(startColor, endColor);

		drawHorizontalGradientRectangle(buffer, x0, y0, x1, y1, z, components.sr(), components.sg(), components.sb(),
		                                components.sa(), components.er(), components.eg(), components.eb(),
		                                components.ea());
	}

	public static void drawHorizontalGradientRectangle(class_287 buffer, float x0, float y0, float x1, float y1,
	                                                   float z, int sr, int sg, int sb, int sa, int er, int eg, int eb,
	                                                   int ea) {
		buffer.method_22912(x0, y0, z).method_1336(sr, sg, sb, sa);
		buffer.method_22912(x0, y1, z).method_1336(sr, sg, sb, sa);
		buffer.method_22912(x1, y1, z).method_1336(er, eg, eb, ea);
		buffer.method_22912(x1, y0, z).method_1336(er, eg, eb, ea);
	}

	private record ColorComponents(int sa, int sr, int sg, int sb, int ea, int er, int eg, int eb) {}
}
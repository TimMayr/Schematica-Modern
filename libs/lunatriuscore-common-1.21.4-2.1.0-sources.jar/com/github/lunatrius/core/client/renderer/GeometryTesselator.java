package com.github.lunatrius.core.client.renderer;

import com.mojang.blaze3d.vertex.*;
import net.minecraft.class_2338;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_4587;
import org.jetbrains.annotations.Nullable;

public class GeometryTesselator extends class_289 {
	@Nullable
	private static GeometryTesselator instance;

	private static double deltaS = 0;

	public GeometryTesselator() {
		this(0x200000);
	}

	public GeometryTesselator(int size) {
		super(size);
	}

	public static GeometryTesselator method_1348() {
		if (instance == null) {
			instance = new GeometryTesselator();
		}

		return instance;
	}

	public static void setStaticDelta(double delta) {
		deltaS = delta;
	}

	public static void drawCuboid(class_287 buffer, class_2338 pos, int sides, int argb,
	                              class_293.class_5596 drawmode) {
		drawCuboid(buffer, pos, pos, sides, argb, drawmode);
	}

	public static void drawCuboid(class_287 buffer, class_2338 begin, class_2338 end, int sides, int argb,
	                              class_293.class_5596 drawmode) {
		drawCuboid(buffer, begin, end, sides, argb, GeometryTesselator.deltaS, drawmode);
	}

	private static void drawCuboid(class_287 buffer, class_2338 begin, class_2338 end, int sides, int argb,
	                               double delta, class_293.class_5596 drawmode) {
		if (sides == 0) {
			return;
		}


		float x0 = (float) (begin.method_10263() - delta);
		float y0 = (float) (begin.method_10264() - delta);
		float z0 = (float) (begin.method_10260() - delta);
		float x1 = (float) (end.method_10263() + 1 + delta);
		float y1 = (float) (end.method_10264() + 1 + delta);
		float z1 = (float) (end.method_10260() + 1 + delta);

		switch (drawmode) {
			case class_293.class_5596.field_27382:
				drawQuads(buffer, x0, y0, z0, x1, y1, z1, sides, argb);
				break;

			case class_293.class_5596.field_27377:
				drawLines(buffer, x0, y0, z0, x1, y1, z1, sides, argb);
				break;

			default:
				throw new IllegalStateException("Unsupported mode!");
		}
	}

	public static void drawQuads(class_287 buffer, float x0, float y0, float z0, float x1, float y1, float z1,
	                             int sides, int argb) {
		int a = (argb >>> 24) & 0xFF;
		int r = (argb >>> 16) & 0xFF;
		int g = (argb >>> 8) & 0xFF;
		int b = argb & 0xFF;

		drawQuads(buffer, x0, y0, z0, x1, y1, z1, sides, a, r, g, b);
	}

	public static void drawQuads(class_287 buffer, float x0, float y0, float z0, float x1, float y1, float z1,
	                             int sides, int a, int r, int g, int b) {
		if ((sides & GeometryMasks.Quad.DOWN) != 0) {
			buffer.method_22912(x1, y0, z0).method_1336(r, g, b, a);
			buffer.method_22912(x1, y0, z1).method_1336(r, g, b, a);
			buffer.method_22912(x0, y0, z1).method_1336(r, g, b, a);
			buffer.method_22912(x0, y0, z0).method_1336(r, g, b, a);
		}

		if ((sides & GeometryMasks.Quad.UP) != 0) {
			buffer.method_22912(x1, y1, z0).method_1336(r, g, b, a);
			buffer.method_22912(x0, y1, z0).method_1336(r, g, b, a);
			buffer.method_22912(x0, y1, z1).method_1336(r, g, b, a);
			buffer.method_22912(x1, y1, z1).method_1336(r, g, b, a);
		}

		if ((sides & GeometryMasks.Quad.NORTH) != 0) {
			buffer.method_22912(x1, y0, z0).method_1336(r, g, b, a);
			buffer.method_22912(x0, y0, z0).method_1336(r, g, b, a);
			buffer.method_22912(x0, y1, z0).method_1336(r, g, b, a);
			buffer.method_22912(x1, y1, z0).method_1336(r, g, b, a);
		}

		if ((sides & GeometryMasks.Quad.SOUTH) != 0) {
			buffer.method_22912(x0, y0, z1).method_1336(r, g, b, a);
			buffer.method_22912(x1, y0, z1).method_1336(r, g, b, a);
			buffer.method_22912(x1, y1, z1).method_1336(r, g, b, a);
			buffer.method_22912(x0, y1, z1).method_1336(r, g, b, a);
		}

		if ((sides & GeometryMasks.Quad.WEST) != 0) {
			buffer.method_22912(x0, y0, z0).method_1336(r, g, b, a);
			buffer.method_22912(x0, y0, z1).method_1336(r, g, b, a);
			buffer.method_22912(x0, y1, z1).method_1336(r, g, b, a);
			buffer.method_22912(x0, y1, z0).method_1336(r, g, b, a);
		}

		if ((sides & GeometryMasks.Quad.EAST) != 0) {
			buffer.method_22912(x1, y0, z1).method_1336(r, g, b, a);
			buffer.method_22912(x1, y0, z0).method_1336(r, g, b, a);
			buffer.method_22912(x1, y1, z0).method_1336(r, g, b, a);
			buffer.method_22912(x1, y1, z1).method_1336(r, g, b, a);
		}
	}

	public static void drawLines(class_287 buffer, float x0, float y0, float z0, float x1, float y1, float z1,
	                             int sides, int argb) {
		int a = (argb >>> 24) & 0xFF;
		int r = (argb >>> 16) & 0xFF;
		int g = (argb >>> 8) & 0xFF;
		int b = argb & 0xFF;

		drawLines(buffer, x0, y0, z0, x1, y1, z1, sides, a, r, g, b);
	}

	public static void drawLines(class_287 buffer, float x0, float y0, float z0, float x1, float y1, float z1,
	                             int sides, int a, int r, int g, int b) {
		if ((sides & GeometryMasks.Line.DOWN_WEST) != 0) {
			buffer.method_22912(x0, y0, z0).method_1336(r, g, b, a);
			buffer.method_22912(x0, y0, z1).method_1336(r, g, b, a);
		}

		if ((sides & GeometryMasks.Line.UP_WEST) != 0) {
			buffer.method_22912(x0, y1, z0).method_1336(r, g, b, a);
			buffer.method_22912(x0, y1, z1).method_1336(r, g, b, a);
		}

		if ((sides & GeometryMasks.Line.DOWN_EAST) != 0) {
			buffer.method_22912(x1, y0, z0).method_1336(r, g, b, a);
			buffer.method_22912(x1, y0, z1).method_1336(r, g, b, a);
		}

		if ((sides & GeometryMasks.Line.UP_EAST) != 0) {
			buffer.method_22912(x1, y1, z0).method_1336(r, g, b, a);
			buffer.method_22912(x1, y1, z1).method_1336(r, g, b, a);
		}

		if ((sides & GeometryMasks.Line.DOWN_NORTH) != 0) {
			buffer.method_22912(x0, y0, z0).method_1336(r, g, b, a);
			buffer.method_22912(x1, y0, z0).method_1336(r, g, b, a);
		}

		if ((sides & GeometryMasks.Line.UP_NORTH) != 0) {
			buffer.method_22912(x0, y1, z0).method_1336(r, g, b, a);
			buffer.method_22912(x1, y1, z0).method_1336(r, g, b, a);
		}

		if ((sides & GeometryMasks.Line.DOWN_SOUTH) != 0) {
			buffer.method_22912(x0, y0, z1).method_1336(r, g, b, a);
			buffer.method_22912(x1, y0, z1).method_1336(r, g, b, a);
		}

		if ((sides & GeometryMasks.Line.UP_SOUTH) != 0) {
			buffer.method_22912(x0, y1, z1).method_1336(r, g, b, a);
			buffer.method_22912(x1, y1, z1).method_1336(r, g, b, a);
		}

		if ((sides & GeometryMasks.Line.NORTH_WEST) != 0) {
			buffer.method_22912(x0, y0, z0).method_1336(r, g, b, a);
			buffer.method_22912(x0, y1, z0).method_1336(r, g, b, a);
		}

		if ((sides & GeometryMasks.Line.NORTH_EAST) != 0) {
			buffer.method_22912(x1, y0, z0).method_1336(r, g, b, a);
			buffer.method_22912(x1, y1, z0).method_1336(r, g, b, a);
		}

		if ((sides & GeometryMasks.Line.SOUTH_WEST) != 0) {
			buffer.method_22912(x0, y0, z1).method_1336(r, g, b, a);
			buffer.method_22912(x0, y1, z1).method_1336(r, g, b, a);
		}

		if ((sides & GeometryMasks.Line.SOUTH_EAST) != 0) {
			buffer.method_22912(x1, y0, z1).method_1336(r, g, b, a);
			buffer.method_22912(x1, y1, z1).method_1336(r, g, b, a);
		}
	}

	public void setTranslation(class_4587 poseStack, double x, double y, double z) {
		poseStack.method_22904(x, y, z);
	}

	public class_287 beginQuads() {
		return begin(class_293.class_5596.field_27382);
	}

	public class_287 begin(class_293.class_5596 mode) {
		return method_60827(mode, class_290.field_1576);
	}

	public class_287 beginLines() {
		return begin(class_293.class_5596.field_27377);
	}
}
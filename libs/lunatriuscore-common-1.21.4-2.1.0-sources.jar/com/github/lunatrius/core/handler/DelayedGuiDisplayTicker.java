package com.github.lunatrius.core.handler;

import dev.architectury.event.events.client.ClientTickEvent;
import net.minecraft.class_437;

public class DelayedGuiDisplayTicker {
	private final class_437 screen;
	private int ticks;
	private ClientTickEvent.Client client;

	private DelayedGuiDisplayTicker(class_437 screen, int delay) {
		this.screen = screen;
		this.ticks = delay;
		this.client = (minecraft) -> {
			this.ticks--;

			if (this.ticks < 0) {
				minecraft.method_1507(this.screen);
				ClientTickEvent.CLIENT_PRE.unregister(client);
			}
		};
	}

	public static void create(class_437 guiScreen, int delay) {
		final DelayedGuiDisplayTicker delayedGuiDisplayTicker = new DelayedGuiDisplayTicker(guiScreen, delay);
		ClientTickEvent.CLIENT_PRE.register(delayedGuiDisplayTicker.client);
	}
}
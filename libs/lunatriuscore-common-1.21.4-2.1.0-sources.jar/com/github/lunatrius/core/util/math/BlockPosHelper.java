package com.github.lunatrius.core.util.math;

import com.google.common.collect.AbstractIterator;
import org.jetbrains.annotations.NotNull;

import java.util.Iterator;
import net.minecraft.class_2338;

public class BlockPosHelper {
	public static Iterable<MBlockPos> getAllInBox(class_2338 from, class_2338 to) {
		return getAllInBox(from.method_10263(), from.method_10264(), from.method_10260(), to.method_10263(), to.method_10264(), to.method_10260());
	}

	public static Iterable<MBlockPos> getAllInBox(int fromX, int fromY, int fromZ, int toX, int toY, int toZ) {
		class_2338 posMin = new class_2338(Math.min(fromX, toX), Math.min(fromY, toY), Math.min(fromZ, toZ));
		class_2338 posMax = new class_2338(Math.max(fromX, toX), Math.max(fromY, toY), Math.max(fromZ, toZ));
		return new Iterable<>() {
			@Override
			@NotNull
			public Iterator<MBlockPos> iterator() {
				return new AbstractIterator<>() {
					private MBlockPos pos = null;
					private int x;
					private int y;
					private int z;

					@Override
					protected MBlockPos computeNext() {
						if (this.pos == null) {
							this.x = posMin.method_10263();
							this.y = posMin.method_10264();
							this.z = posMin.method_10260();
							this.pos = new MBlockPos(this.x, this.y, this.z);
							return this.pos;
						}

						if (this.pos.equals(posMax)) {
							return this.endOfData();
						}

						if (this.x < posMax.method_10263()) {
							this.x++;
						} else if (this.y < posMax.method_10264()) {
							this.x = posMin.method_10263();
							this.y++;
						} else if (this.z < posMax.method_10260()) {
							this.x = posMin.method_10263();
							this.y = posMin.method_10264();
							this.z++;
						}

						this.pos.x = this.x;
						this.pos.y = this.y;
						this.pos.z = this.z;
						return this.pos;
					}
				};
			}
		};
	}

	public static Iterable<MBlockPos> getAllInBoxXZY(class_2338 from, class_2338 to) {
		return getAllInBoxXZY(from.method_10263(), from.method_10264(), from.method_10260(), to.method_10263(), to.method_10264(), to.method_10260());
	}

	public static Iterable<MBlockPos> getAllInBoxXZY(int fromX, int fromY, int fromZ, int toX, int toY, int toZ) {
		class_2338 posMin = new class_2338(Math.min(fromX, toX), Math.min(fromY, toY), Math.min(fromZ, toZ));
		class_2338 posMax = new class_2338(Math.max(fromX, toX), Math.max(fromY, toY), Math.max(fromZ, toZ));
		return new Iterable<>() {
			@Override
			@NotNull
			public Iterator<MBlockPos> iterator() {
				return new AbstractIterator<>() {
					private MBlockPos pos = null;
					private int x;
					private int y;
					private int z;

					@Override
					protected MBlockPos computeNext() {
						if (this.pos == null) {
							this.x = posMin.method_10263();
							this.y = posMin.method_10264();
							this.z = posMin.method_10260();
							this.pos = new MBlockPos(this.x, this.y, this.z);
							return this.pos;
						}

						if (this.pos.equals(posMax)) {
							return this.endOfData();
						}

						if (this.x < posMax.method_10263()) {
							this.x++;
						} else if (this.z < posMax.method_10260()) {
							this.x = posMin.method_10263();
							this.z++;
						} else if (this.y < posMax.method_10264()) {
							this.x = posMin.method_10263();
							this.z = posMin.method_10260();
							this.y++;
						}

						this.pos.x = this.x;
						this.pos.y = this.y;
						this.pos.z = this.z;
						return this.pos;
					}
				};
			}
		};
	}

	public static Iterable<MBlockPos> getAllInBoxYXZ(class_2338 from, class_2338 to) {
		return getAllInBoxYXZ(from.method_10263(), from.method_10264(), from.method_10260(), to.method_10263(), to.method_10264(), to.method_10260());
	}

	public static Iterable<MBlockPos> getAllInBoxYXZ(int fromX, int fromY, int fromZ, int toX, int toY, int toZ) {
		class_2338 posMin = new class_2338(Math.min(fromX, toX), Math.min(fromY, toY), Math.min(fromZ, toZ));
		class_2338 posMax = new class_2338(Math.max(fromX, toX), Math.max(fromY, toY), Math.max(fromZ, toZ));
		return new Iterable<>() {
			@Override
			@NotNull
			public Iterator<MBlockPos> iterator() {
				return new AbstractIterator<>() {
					private MBlockPos pos = null;
					private int x;
					private int y;
					private int z;

					@Override
					protected MBlockPos computeNext() {
						if (this.pos == null) {
							this.x = posMin.method_10263();
							this.y = posMin.method_10264();
							this.z = posMin.method_10260();
							this.pos = new MBlockPos(this.x, this.y, this.z);
							return this.pos;
						}

						if (this.pos.equals(posMax)) {
							return this.endOfData();
						}

						if (this.y < posMax.method_10264()) {
							this.y++;
						} else if (this.x < posMax.method_10263()) {
							this.y = posMin.method_10264();
							this.x++;
						} else if (this.z < posMax.method_10260()) {
							this.y = posMin.method_10264();
							this.x = posMin.method_10263();
							this.z++;
						}

						this.pos.x = this.x;
						this.pos.y = this.y;
						this.pos.z = this.z;
						return this.pos;
					}
				};
			}
		};
	}
}
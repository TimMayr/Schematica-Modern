package com.github.lunatrius.core.util.math;

import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_6328;
import org.jetbrains.annotations.NotNull;

@class_6328
public class MBlockPos extends class_2338 {
	public int x;
	public int y;
	public int z;

	public MBlockPos() {
		this(0, 0, 0);
	}

	public MBlockPos(int x, int y, int z) {
		super(0, 0, 0);
		this.x = x;
		this.y = y;
		this.z = z;
	}

	public MBlockPos(@NotNull class_1297 source) {
		this(source.method_23317(), source.method_23318(), source.method_23321());
	}

	public MBlockPos(double x, double y, double z) {
		this((int) Math.floor(x), (int) Math.floor(y), (int) Math.floor(z));
	}

	public MBlockPos(@NotNull class_243 source) {
		this(source.field_1352, source.field_1351, source.field_1350);
	}

	public MBlockPos(@NotNull class_2382 source) {
		this(source.method_10263(), source.method_10264(), source.method_10260());
	}

	public MBlockPos set(@NotNull class_1297 source) {
		return set(source.method_23317(), source.method_23318(), source.method_23321());
	}

	public MBlockPos set(double x, double y, double z) {
		return set((int) Math.floor(x), (int) Math.floor(y), (int) Math.floor(z));
	}

	public MBlockPos set(int x, int y, int z) {
		this.x = x;
		this.y = y;
		this.z = z;
		return this;
	}

	public MBlockPos set(@NotNull class_243 source) {
		return set(source.field_1352, source.field_1351, source.field_1350);
	}

	public MBlockPos set(@NotNull class_2382 source) {
		return set(source.method_10263(), source.method_10264(), source.method_10260());
	}

	public MBlockPos subtract(double x, double y, double z) {
		return subtract((int) x, (int) y, (int) z);
	}

	public MBlockPos subtract(int x, int y, int z) {
		return new MBlockPos(this.x - x, this.y - y, this.z - z);
	}

	public MBlockPos offset(double x, double y, double z) {
		return method_34592((int) x, (int) y, (int) z);
	}

	@Override
	public MBlockPos method_34592(int x, int y, int z) {
		return new MBlockPos(this.x + x, this.y + y, this.z + z);
	}

	@Override
	public MBlockPos method_35853(@NotNull class_2382 vec) {
		return method_34592(vec.method_10263(), vec.method_10264(), vec.method_10260());
	}

	public MBlockPos method_35852(@NotNull class_2382 vec) {
		return subtract(vec.method_10263(), vec.method_10264(), vec.method_10260());
	}

	public MBlockPos method_35862(int factor) {
		return new MBlockPos(this.x * factor, this.y * factor, this.z * factor);
	}

	@Override
	public MBlockPos method_30931() {
		return method_30930(1);
	}

	@Override
	public MBlockPos method_30930(int n) {
		return method_23226(class_2350.field_11036, n);
	}

	@Override
	public MBlockPos method_23228() {
		return method_23227(1);
	}

	@Override
	public MBlockPos method_23227(int n) {
		return method_23226(class_2350.field_11033, n);
	}

	@Override
	public MBlockPos method_35861() {
		return method_35860(1);
	}

	@Override
	public MBlockPos method_35860(int n) {
		return method_23226(class_2350.field_11043, n);
	}

	@Override
	public MBlockPos method_35859() {
		return method_35858(1);
	}

	@Override
	public MBlockPos method_35858(int n) {
		return method_23226(class_2350.field_11035, n);
	}

	@Override
	public MBlockPos method_35857() {
		return method_35856(1);
	}

	@Override
	public MBlockPos method_35856(int n) {
		return method_23226(class_2350.field_11039, n);
	}

	@Override
	public MBlockPos method_35855() {
		return method_35854(1);
	}

	@Override
	public MBlockPos method_35854(int n) {
		return method_23226(class_2350.field_11034, n);
	}

	@Override
	public MBlockPos method_35851(class_2350 facing) {
		return method_23226(facing, 1);
	}

	@Override
	public MBlockPos method_23226(@NotNull class_2350 facing, int n) {
		return new MBlockPos(this.x + facing.method_10148() * n, this.y + facing.method_10164() * n,
				this.z + facing.method_10165() * n);
	}

	@Override
	public MBlockPos method_10259(@NotNull class_2382 vec) {
		return new MBlockPos(this.y * vec.method_10260() - this.z * vec.method_10264(), this.z * vec.method_10263() - this.x * vec.method_10260(),
				this.x * vec.method_10264() - this.y * vec.method_10263());
	}

	@Override
	public class_2338 method_10062() {
		return new class_2338(this);
	}

	@Override
	public int method_10263() {
		return this.x;
	}

	@Override
	public int method_10264() {
		return this.y;
	}

	@Override
	public int method_10260() {
		return this.z;
	}

	@Override
	public String toString() {
		return String.format("%d %d %d", x, y, z);
	}
}
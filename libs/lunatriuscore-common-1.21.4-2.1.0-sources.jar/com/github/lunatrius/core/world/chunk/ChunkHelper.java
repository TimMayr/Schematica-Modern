package com.github.lunatrius.core.world.chunk;

import java.util.Random;
import net.minecraft.class_2338;

public class ChunkHelper {
	private static final Random RANDOM = new Random();

	public static boolean isSlimeChunk(long seed, class_2338 pos) {
		int x = pos.method_10263() >> 4;
		int z = pos.method_10260() >> 4;
		RANDOM.setSeed(seed + ((long) x * x * 4987142) + (x * 5947611L) + (long) z * z * 4392871L + (z * 389711L)
				               ^ 987234911L);
		return RANDOM.nextInt(10) == 0;
	}
}